#pragma once
class node
{
public:
	node* next;
	int data;

};

class LinkedList
{
private:
	node* head;
	int length;
public:
	LinkedList();
	void insert(int data);
	void display();

};