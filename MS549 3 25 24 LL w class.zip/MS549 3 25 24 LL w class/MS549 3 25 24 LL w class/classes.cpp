#include <iostream>
#include "classes.h"

using namespace std;
LinkedList::LinkedList()
{
	head = NULL;
}

void LinkedList::display()
{
	node* curr = head;
	while (curr)
	{
		cout << "node = " << curr->data;
		curr = curr->next;
	}


}

void LinkedList::insert(int number)
{
	node* newnode = new node();
	newnode->data = number;
	newnode->next = head;
	head = newnode;
}