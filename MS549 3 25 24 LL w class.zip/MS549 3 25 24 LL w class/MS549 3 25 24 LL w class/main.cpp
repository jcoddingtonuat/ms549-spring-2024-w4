#include <iostream>
#include "classes.h"

using namespace std;

int main()
{
	LinkedList LList;
	for (int i = 0; i < 100; i++)
	{
		LList.insert(rand() % 100);
	}

	LList.display();
	return 0;

}